<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateChatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('chats', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('userfrom');
            $table->foreign('userfrom')->references('id')->on('users');

            $table->unsignedBigInteger('userto');
            $table->foreign('userto')->references('id')->on('users');
			
			$table->unsignedBigInteger('company_id')->nullable();
            $table->foreign('company_id')->references('id')->on('companys');

            $table->longText('text')->nullable();
            $table->string('note')->nullable();
            $table->boolean('status')->default(1); 
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('chats');
    }
}
