<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            #$table->unsignedBigInteger('document_id')->nullable();
            #$table->foreign('document_id')->references('id')->on('documents');

            $table->string('document')->nullable();

            $table->unsignedBigInteger('typeuser_id');
            $table->foreign('typeuser_id')->references('id')->on('typeusers');			
			
            $table->string('name');
            $table->string('lastname')->nullable();
            $table->string('email');
            $table->date('fechanac')->nullable();
            $table->string('genero', 20)->nullable();
            $table->longText('avatar')->nullable();
            
            $table->unsignedBigInteger('codepai_id')->nullable();
            $table->foreign('codepai_id')->references('id')->on('codepais');
            $table->string('phone')->nullable();
			
			$table->unsignedBigInteger('company_id')->nullable();
            $table->foreign('company_id')->references('id')->on('companys');
			
			$table->string('codesms')->nullable();
			$table->boolean('confirmsms')->default(0);
            $table->boolean('connected')->default(0);
            $table->boolean('status')->default(1);
            //$table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
